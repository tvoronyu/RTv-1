#include "fractol.h"

int		exit_x(t_struct *ptr)
{
	mlx_destroy_window(ptr->mlx_ptr, ptr->mlx_win);
	ptr = NULL;
	exit(0);
}

int		deal_key(int key)
{
	if (key == 53)
		exit(0);
	return (0);
}

int main(int argc, char *argv[])
{
	t_struct ptr[1];
	
	ptr->cam.x = 0;
	ptr->cam.y = 0;
	ptr->cam.z = 0;
	
	ptr->t = 1000000;
	
	
	
	
	
	
	
	ptr->mlx_ptr = mlx_init();
	ptr->mlx_win = mlx_new_window(ptr->mlx_ptr, CW, CH, "RTv_1");


	
	
	
	
	

	ptr->sfr.center.x = 0;
	ptr->sfr.center.y = 70;
	ptr->sfr.center.z = 35;

	ptr->sfr.r = 1;

	ptr->sfr.color.x = 0;
	ptr->sfr.color.y = 255;
	ptr->sfr.color.z = 0;
	ft_main(ptr);
	
	ptr->sfr.center.x = 100;
	ptr->sfr.center.y = -10;
	ptr->sfr.center.z = 0;

	ptr->sfr.r = 1;

	ptr->sfr.color.x = 0;
	ptr->sfr.color.y = 0;
	ptr->sfr.color.z = 255;
	ft_main(ptr);
	
	ptr->sfr.center.x = -100;
	ptr->sfr.center.y = -10;
	ptr->sfr.center.z = 0;
	
	ptr->sfr.r = 1;
	
	ptr->sfr.color.x = 255;
	ptr->sfr.color.y = 0;
	ptr->sfr.color.z = 0;
	
	ft_main(ptr);
	
	mlx_hook(ptr->mlx_win, 17, 1L << 17, exit_x, ptr);
	mlx_hook(ptr->mlx_win, 2, 5, deal_key, (void*)0);
	mlx_loop(ptr->mlx_ptr);
	return (0);
}